#ifndef __VL53L0X_h__
#define __VL53L0X_h__

#ifdef __cplusplus
 extern "C" {
#endif


#include "main.h"
// I2C_HandleTypeDef hi2c1;
extern I2C_HandleTypeDef hi2c3;

 typedef enum {
	 true=1,
	 false=0,

 }bool;
 extern enum regAddr;

typedef enum vcselPeriodType {
	 VcselPeriodPreRange,
	 VcselPeriodFinalRange
}vcselPeriodType;

extern uint8_t last_status; // status of last I2C transmission
extern uint8_t address;
extern uint16_t io_timeout;
extern bool did_timeout;
extern uint16_t timeout_start_ms;
extern uint8_t stop_variable; // read by init and used when starting measurement; is StopVariable field of VL53L0X_DevData_t structure in API
extern uint32_t measurement_timing_budget_us;

void setAddress(uint8_t new_addr);
inline uint8_t getAddress(void) { return address; }

bool init(bool io_2v8);// = true);

void writeReg(uint8_t reg, uint8_t value);
void writeReg16Bit(uint8_t reg, uint16_t value);
void writeReg32Bit(uint8_t reg, uint32_t value);
uint8_t readReg(uint8_t reg);
uint16_t readReg16Bit(uint8_t reg);
uint32_t readReg32Bit(uint8_t reg);
uint32_t millis();
void writeMulti(uint8_t reg, uint8_t const * src, uint8_t count);
void readMulti(uint8_t reg, uint8_t * dst, uint8_t count);

bool setSignalRateLimit(float limit_Mcps);
float getSignalRateLimit(void);

bool setMeasurementTimingBudget(uint32_t budget_us);
uint32_t getMeasurementTimingBudget(void);

bool setVcselPulsePeriod(vcselPeriodType type, uint8_t period_pclks);
uint8_t getVcselPulsePeriod(vcselPeriodType type);

void startContinuous(uint32_t period_ms);// = 0);
void stopContinuous(void);
uint16_t readRangeContinuousMillimeters(void);
uint16_t readRangeSingleMillimeters(void);

inline void setTimeout(uint16_t timeout) { io_timeout = timeout; }
inline uint16_t getTimeout(void) { return io_timeout; }
bool timeoutOccurred(void);

// TCC: Target CentreCheck
// MSRC: Minimum Signal Rate Check
// DSS: Dynamic Spad Selection

struct SequenceStepEnables{
  bool tcc, msrc, dss, pre_range, final_range;
};

struct SequenceStepTimeouts{
  uint16_t pre_range_vcsel_period_pclks, final_range_vcsel_period_pclks;

  uint16_t msrc_dss_tcc_mclks, pre_range_mclks, final_range_mclks;
  uint32_t msrc_dss_tcc_us,    pre_range_us,    final_range_us;
};




bool getSpadInfo(uint8_t * count, bool * type_is_aperture);

void getSequenceStepEnables(struct SequenceStepEnables *enables);
void getSequenceStepTimeouts(struct SequenceStepEnables const * enables, struct SequenceStepTimeouts *timeouts);

bool performSingleRefCalibration(uint8_t vhv_init_byte);

static uint16_t decodeTimeout(uint16_t value);
static uint16_t encodeTimeout(uint16_t timeout_mclks);
static uint32_t timeoutMclksToMicroseconds(uint16_t timeout_period_mclks, uint8_t vcsel_period_pclks);
static uint32_t timeoutMicrosecondsToMclks(uint32_t timeout_period_us, uint8_t vcsel_period_pclks);

#ifdef __cplusplus
}
#endif

#endif /* __VL53L0X_h__ */

